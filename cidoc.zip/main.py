import rdflib
g=rdflib.Graph()
g.parse("demo.xml", format="xml")